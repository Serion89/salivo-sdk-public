Stage 3 compiler directory (SALIVO_STAGE3_DIR). The runtime is prebuilt in ../../target.
